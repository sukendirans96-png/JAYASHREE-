package com.jayashree.nearbychat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID

 data class Device(val id: String, val name: String)
 data class PendingRequest(val endpointId: String, val name: String, val digits: String)
 data class ChatMessage(val id: String, val text: String, val mine: Boolean, val time: Long, val delivered: Boolean)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("jayashree_history", 0)
    private val _devices = MutableStateFlow<List<Device>>(emptyList()); val devices = _devices.asStateFlow()
    private val _messages = MutableStateFlow(load()); val messages = _messages.asStateFlow()
    private val _connected = MutableStateFlow(false); val connected = _connected.asStateFlow()
    private val _status = MutableStateFlow("Ready"); val status = _status.asStateFlow()
    private val _pending = MutableStateFlow<PendingRequest?>(null); val pending = _pending.asStateFlow()
    private var reconnectId: String? = null
    private var reconnectName: String? = null

    private val manager = NearbyChatManager(app,
        onFound = { id, name ->
            if (_devices.value.none { it.id == id }) _devices.value = _devices.value + Device(id, name)
        },
        onLost = { id -> _devices.value = _devices.value.filterNot { it.id == id } },
        onPendingConnection = { id, name, digits, accept, reject ->
            _pending.value = PendingRequest(id, name, digits)
            pendingAccept = accept; pendingReject = reject
        },
        onConnected = { id, _ ->
            _connected.value = true; _status.value = "Connected"; reconnectId = id
            reconnectName = _devices.value.firstOrNull { it.id == id }?.name ?: reconnectName
        },
        onDisconnected = { id ->
            _connected.value = false; _status.value = "Reconnecting…"; reconnectId = id
            manager.startDiscovery()
        },
        onPayload = { _, bytes -> handlePayload(bytes) },
        onError = { _status.value = it }
    )

    private var pendingAccept: (() -> Unit)? = null
    private var pendingReject: (() -> Unit)? = null

    fun acceptPending() { pendingAccept?.invoke(); clearPending() }
    fun rejectPending() { pendingReject?.invoke(); clearPending() }
    private fun clearPending() { pendingAccept = null; pendingReject = null; _pending.value = null }

    fun advertise() { _status.value = "Discoverable"; manager.startAdvertising("JAYASHREE User") }
    fun discover() { _devices.value = emptyList(); _status.value = "Scanning…"; manager.startDiscovery() }
    fun connect(id: String) { reconnectId = id; reconnectName = _devices.value.firstOrNull { it.id == id }?.name; _status.value = "Connecting…"; manager.requestConnection(id) }
    fun reconnect() { reconnectId?.let { _status.value = "Reconnecting…"; manager.reconnectTo(it) } ?: discover() }

    fun send(text: String) {
        val id = UUID.randomUUID().toString()
        val obj = JSONObject().apply { put("type","message"); put("id",id); put("text",text); put("time",System.currentTimeMillis()) }
        if (!manager.send(obj.toString().toByteArray())) return
        _messages.value = _messages.value + ChatMessage(id,text,true,System.currentTimeMillis(),false); save()
    }

    private fun handlePayload(bytes: ByteArray) {
        val raw = String(bytes, Charsets.UTF_8)
        try {
            val j = JSONObject(raw)
            when (j.optString("type")) {
                "message" -> {
                    val id=j.getString("id"); val text=j.getString("text"); val time=j.optLong("time",System.currentTimeMillis())
                    if (_messages.value.none { it.id == id }) _messages.value += ChatMessage(id,text,false,time,true)
                    save()
                    manager.send(JSONObject().apply { put("type","ack"); put("id",id) }.toString().toByteArray())
                }
                "ack" -> {
                    val id=j.getString("id")
                    _messages.value = _messages.value.map { if (it.id==id) it.copy(delivered=true) else it }; save()
                }
            }
        } catch (_: Exception) { }
    }

    private fun load(): List<ChatMessage> = try {
        val a=org.json.JSONArray(prefs.getString("messages","[]")!!); List(a.length()){i->val j=a.getJSONObject(i);ChatMessage(j.getString("id"),j.getString("text"),j.getBoolean("mine"),j.getLong("time"),j.optBoolean("delivered"))}
    } catch (_: Exception) { emptyList() }
    private fun save() {
        val a=org.json.JSONArray(); _messages.value.forEach{m->a.put(JSONObject().apply{put("id",m.id);put("text",m.text);put("mine",m.mine);put("time",m.time);put("delivered",m.delivered)})}; prefs.edit().putString("messages",a.toString()).apply()
    }
    fun clearHistory(){_messages.value=emptyList();prefs.edit().remove("messages").apply()}
    override fun onCleared(){manager.stopAll();super.onCleared()}
}
