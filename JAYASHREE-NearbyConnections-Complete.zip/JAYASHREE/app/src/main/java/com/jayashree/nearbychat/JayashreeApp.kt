package com.jayashree.nearbychat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable fun JayashreeApp(vm: ChatViewModel = viewModel()){
    var page by remember{mutableStateOf("home")}; val pending by vm.pending.collectAsState(); val connected by vm.connected.collectAsState(); val status by vm.status.collectAsState()
    if(pending!=null) AlertDialog(onDismissRequest={vm.rejectPending()},title={Text("Connect to ${pending!!.name}")},text={Text("Confirm this code on both phones:\n\n${pending!!.digits}")},confirmButton={Button({vm.acceptPending()}){Text("Accept")}},dismissButton={TextButton({vm.rejectPending()}){Text("Reject")}})
    when(page){
        "home"->Home(status,{vm.discover();page="nearby"},{vm.advertise();page="nearby"})
        "nearby"->Nearby(vm,status,{page="home"},{page="chat"})
        else->Chat(vm,status,connected,{page="nearby"})
    }
}

@Composable private fun Home(status:String,find:()->Unit,advertise:()->Unit){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Box(Modifier.size(96.dp).clip(CircleShape).then(Modifier),contentAlignment=Alignment.Center){Text("J",fontSize=56.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)};Text("JAYASHREE",fontSize=32.sp,fontWeight=FontWeight.Bold);Text("Nearby • Private • Offline",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(36.dp));Button(find,Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.Search,null);Spacer(Modifier.width(8.dp));Text("Find Nearby Phones")};Spacer(Modifier.height(12.dp));OutlinedButton(advertise,Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.Wifi,null);Spacer(Modifier.width(8.dp));Text("Make Me Discoverable")};Spacer(Modifier.height(20.dp));Text(status,fontSize=12.sp,color=MaterialTheme.colorScheme.primary)}}

@Composable private fun Nearby(vm:ChatViewModel,status:String,back:()->Unit,chat:()->Unit){val devices by vm.devices.collectAsState();val connected by vm.connected.collectAsState();LaunchedEffect(connected){if(connected)chat()};Column(Modifier.fillMaxSize().padding(20.dp)){TextButton(back){Text("← Back")};Text("Nearby Phones",fontSize=28.sp,fontWeight=FontWeight.Bold);Text(status,color=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(16.dp));Button({vm.discover()},Modifier.fillMaxWidth().height(52.dp)){Icon(Icons.Default.Search,null);Spacer(Modifier.width(8.dp));Text("Scan Again")};Spacer(Modifier.height(18.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(devices,key={it.id}){d->Card(onClick={vm.connect(d.id)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null)};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(d.name,fontWeight=FontWeight.SemiBold);Text("Nearby device",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Icon(Icons.Default.ChevronRight,null)}}}}}}

@Composable private fun Chat(vm:ChatViewModel,status:String,connected:Boolean,back:()->Unit){val messages by vm.messages.collectAsState();var input by remember{mutableStateOf("")};val list=rememberLazyListState();LaunchedEffect(messages.size){if(messages.isNotEmpty())list.animateScrollToItem(messages.lastIndex)};Column(Modifier.fillMaxSize()){Surface(tonalElevation=4.dp){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Box(Modifier.size(44.dp).clip(CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null)};Spacer(Modifier.width(10.dp));Column{Text("JAYASHREE",fontWeight=FontWeight.Bold);Text(if(connected)"● Connected" else status,fontSize=12.sp,color=MaterialTheme.colorScheme.primary)}}};LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),state=list,verticalArrangement=Arrangement.spacedBy(7.dp),contentPadding=PaddingValues(vertical=14.dp)){items(messages,key={it.id}){Bubble(it)}};Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.Bottom){OutlinedTextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Message")},maxLines=4,shape=RoundedCornerShape(24.dp));Spacer(Modifier.width(8.dp));FloatingActionButton({val t=input.trim();if(t.isNotEmpty()&&connected){vm.send(t);input=""}}){Icon(Icons.Default.Send,"Send")}}}}

@Composable private fun Bubble(m:ChatMessage){Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.mine)Arrangement.End else Arrangement.Start){Surface(color=if(m.mine)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(horizontal=14.dp,vertical=9.dp)){Text(m.text);Row(verticalAlignment=Alignment.CenterVertically){Text(SimpleDateFormat("hh:mm a",Locale.getDefault()).format(Date(m.time)),fontSize=10.sp);if(m.mine){Spacer(Modifier.width(5.dp));Text(if(m.delivered)"✓✓" else "✓",fontSize=11.sp,color=MaterialTheme.colorScheme.primary)}}}}}}
