package com.jayashree.nearbychat

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); requestNearbyPermissions(); setContent { JayashreeApp() } }
    private fun requestNearbyPermissions(){
        val p=mutableListOf<String>()
        if(Build.VERSION.SDK_INT>=31){p+=Manifest.permission.BLUETOOTH_SCAN;p+=Manifest.permission.BLUETOOTH_CONNECT;p+=Manifest.permission.BLUETOOTH_ADVERTISE}
        if(Build.VERSION.SDK_INT in 29..31)p+=Manifest.permission.ACCESS_FINE_LOCATION
        if(Build.VERSION.SDK_INT<=28)p+=Manifest.permission.ACCESS_COARSE_LOCATION
        if(Build.VERSION.SDK_INT>=32)p+=Manifest.permission.NEARBY_WIFI_DEVICES
        permissions.launch(p.distinct().toTypedArray())
    }
}
