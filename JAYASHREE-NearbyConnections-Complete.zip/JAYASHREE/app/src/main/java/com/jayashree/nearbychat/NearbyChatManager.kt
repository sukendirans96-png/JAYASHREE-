package com.jayashree.nearbychat

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.util.concurrent.ConcurrentHashMap

class NearbyChatManager(
    context: Context,
    private val onFound: (String, String) -> Unit,
    private val onLost: (String) -> Unit,
    private val onPendingConnection: (String, String, String, () -> Unit, () -> Unit) -> Unit,
    private val onConnected: (String, String) -> Unit,
    private val onDisconnected: (String) -> Unit,
    private val onPayload: (String, ByteArray) -> Unit,
    private val onError: (String) -> Unit
) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = context.packageName
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private val pending = ConcurrentHashMap<String, String>()
    @Volatile private var connectedEndpoint: String? = null
    @Volatile private var myName: String = "JAYASHREE User"

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            payload.asBytes()?.let { onPayload(endpointId, it) }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) = Unit
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            pending[endpointId] = info.endpointName
            onPendingConnection(endpointId, info.endpointName, info.authenticationDigits,
                { accept(endpointId) }, { reject(endpointId) })
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                connectedEndpoint = endpointId
                pending.remove(endpointId)
                client.stopDiscovery()
                onConnected(endpointId, "Connected")
            } else {
                pending.remove(endpointId)
                onError("Connection failed: ${result.status.statusMessage}")
            }
        }
        override fun onDisconnected(endpointId: String) {
            if (connectedEndpoint == endpointId) connectedEndpoint = null
            onDisconnected(endpointId)
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            onFound(endpointId, info.endpointName)
        }
        override fun onEndpointLost(endpointId: String) = onLost(endpointId)
    }

    fun startAdvertising(name: String) {
        myName = name
        client.stopAdvertising()
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(name, serviceId, lifecycle, options)
            .addOnFailureListener { onError("Advertising failed: ${it.message}") }
    }

    fun startDiscovery() {
        client.stopDiscovery()
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, discovery, options)
            .addOnFailureListener { onError("Discovery failed: ${it.message}") }
    }

    fun requestConnection(endpointId: String) {
        client.requestConnection(myName, endpointId, lifecycle)
            .addOnFailureListener { onError("Request failed: ${it.message}") }
    }

    private fun accept(endpointId: String) {
        client.acceptConnection(endpointId, payloadCallback)
            .addOnFailureListener { onError("Accept failed: ${it.message}") }
    }

    private fun reject(endpointId: String) { client.rejectConnection(endpointId) }

    fun send(bytes: ByteArray): Boolean {
        val endpoint = connectedEndpoint ?: return false
        client.sendPayload(endpoint, Payload.fromBytes(bytes))
            .addOnFailureListener { onError("Send failed: ${it.message}") }
        return true
    }

    fun reconnectTo(endpointId: String) {
        requestConnection(endpointId)
    }

    fun stopDiscovery() { client.stopDiscovery() }
    fun stopAdvertising() { client.stopAdvertising() }
    fun stopAll() { client.stopAllEndpoints(); client.stopDiscovery(); client.stopAdvertising(); connectedEndpoint = null }
}
